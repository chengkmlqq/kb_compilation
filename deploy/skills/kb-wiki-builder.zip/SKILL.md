---
name: kb-wiki-builder
description: "Use when a document in the kb_compilation knowledge base needs to be compiled into wiki pages automatically after ingestion. 把已解析的文档编译进知识库 wiki：读取文档 chunks，调用 LLM 生成结构化 wiki 页面（摘要/实体/概念），写入 kb wiki。由知识库平台在文档处理完成后自动触发。"
---

# kb_compilation 文档 → Wiki 构建

当知识库平台完成文档解析/向量化后自动触发本技能：把该文档的内容编译成
结构化 wiki 页面（文档摘要页 + 实体概念页），写入 kb_compilation 的 wiki。

## 触发环境（agent-gateway 自动注入）

- `WEKNORA_KB_ID` —— 目标知识库 id（覆盖 config.yaml 固定 kb_id）
- `WEKNORA_DOC_NAME` —— 待编译的文档 id
- `WEKNORA_LLM_BASE_URL/MODEL/API_KEY` 或 `LLM_BASE_URL/LLM_MODEL/LLM_API_KEY` —— 任务级 LLM 配置（优先），否则回退 `config.yaml` 的 `model:` 段
- `KB_API_BASE_URL` —— kb_compilation API 入口（默认 http://10.1.215.50）
- `KB_API_USER` / `KB_API_PWD` —— kb 平台服务账号（默认 admin/sys）

## 执行步骤

```bash
python3 scripts/build_wiki.py
```

脚本逻辑：
1. 读取 `WEKNORA_KB_ID`（kb_id）+ `WEKNORA_DOC_NAME`（document_id）；
   kb_id 缺失时回退 `config.yaml` 的 `kb.kb_id`
2. 登录 kb 平台（`POST /api/v1/auth/login`）拿身份 cookie
3. `GET /api/v1/kbs/{kb_id}/documents/{document_id}/chunks` 拉取文档全部文本块
4. 截取前 N 个 chunk（默认前 60 块、每块 2000 字符上限）作为 LLM 输入
5. LLM 生成：文档标题 + 中文摘要（200-400 字）+ 3~8 个实体/概念条目
6. `POST /api/v1/kbs/{kb_id}/wiki/pages` 写入：
   - 摘要页：`page_type=summary`，slug=`doc-<md5前10>`
   - 实体页：`page_type=entity`，slug=`entity-<md5前8>`
7. 输出写入结果摘要（页面 slug 列表）

## 坑位

- 所有脚本必须通过 `scripts/kb_rpc.py` 调 kb API（统一登录/重试），禁止直接硬编码 URL
- 不把 kb_id 写死在脚本里——一律读环境变量或 `config.yaml`
- LLM 配置：优先任务级环境变量（`WEKNORA_LLM_*` / `LLM_*`），回退 config.yaml `model:` 段
- 幂等：同文档重复触发时先查 `POST /wiki/pages` 返回的 slug 冲突，已存在则 `PUT` 更新（slug 相同即覆盖）