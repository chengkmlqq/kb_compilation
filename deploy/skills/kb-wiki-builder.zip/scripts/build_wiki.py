#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""kb-wiki-builder 主脚本：把已解析文档编译进知识库 wiki。

流程：
1. 读目标（kb_id=WEKNORA_KB_ID, document_id=WEKNORA_DOC_NAME）
2. 拉文档 chunks
3. LLM 生成：文档标题 + 摘要 + 实体/概念条目
4. 写入 wiki（summary 页 + entity 页）

用法:  python3 scripts/build_wiki.py [--kb <kb_id>] [--doc <document_id>] [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import kb_rpc as kr

PROMPT = """你是知识库 wiki 构建专家。根据下面的文档内容，生成结构化 wiki 页面数据。
必须返回**纯 JSON**（不要 markdown 代码块），格式：
{{
  "title": "文档标题（中文，去除序号前缀）",
  "summary": "文档摘要（200-400 字，概括主题、适用范围、核心要点）",
  "entities": [
    {{"name": "实体/概念名", "definition": "一句话定义（30-80 字）"}}
  ]
}}
entities 数量 3-8 个，提取文档中最重要的业务概念、制度条款、专有名词。
只输出 JSON，不要任何额外文字。

文档内容：
{content}"""


def _build_prompt(chunks: list[dict], max_chunks: int, chunk_chars: int) -> str:
    config = kr._load_config().get("build", {})
    max_chunks = max_chunks or int(config.get("max_chunks", 60))
    chunk_chars = chunk_chars or int(config.get("chunk_chars", 2000))
    parts = []
    for c in chunks[:max_chunks]:
        text = (c.get("content") or "").strip()
        if len(text) > chunk_chars:
            text = text[:chunk_chars] + "…"
        if text:
            parts.append(f"[块{c.get('seq') or 0}]\n{text}")
    content = "\n\n".join(parts)
    if not content:
        raise RuntimeError("文档 chunks 为空，无法构建 wiki")
    return PROMPT.format(content=content[:30000])


def _parse_llm_json(text: str) -> dict:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise RuntimeError(f"LLM 未返回 JSON: {text[:200]}")
    return json.loads(text[start : end + 1])


def build_wiki(kb_id: str, document_id: str, dry_run: bool = False) -> dict:
    config = kr._load_config()
    build_cfg = config.get("build", {})

    # 1) 拉 chunks
    chunks = kr.fetch_document_chunks(kb_id, document_id)
    if not chunks:
        # 2026-10-05 实测: 文档删除后任务仍「SUCCESS 假成功」——这里必须非零退出，
        # 让 run_skill_script 工具返回失败 → agent 任务 FAILED（用户可见原因）。
        msg = f"文档无 chunks（可能已删除或尚未解析完成）: {document_id}"
        print(msg, file=sys.stderr)
        sys.exit(1)

    # 2) LLM 生成
    prompt = _build_prompt(chunks, build_cfg.get("max_chunks"), build_cfg.get("chunk_chars"))
    raw = kr.llm_chat([{"role": "user", "content": prompt}])
    data = _parse_llm_json(raw)

    title = str(data.get("title") or f"文档 {document_id}").strip()
    summary = str(data.get("summary") or "").strip()
    entities = data.get("entities") or []

    if dry_run:
        return {
            "success": True,
            "dry_run": True,
            "kb_id": kb_id,
            "document_id": document_id,
            "title": title,
            "summary": summary,
            "entities": entities,
            "chunk_count": len(chunks),
        }

    # 3) 写 wiki
    created: list[dict] = []
    # 摘要页
    slug_summary = f"doc-{kr.md5_hex(document_id, 10)}"
    resp = kr.api_post(
        f"/api/v1/kbs/{kb_id}/wiki/pages",
        {"title": title, "content": summary, "slug": slug_summary, "page_type": "summary"},
    )
    created.append({"slug": slug_summary, "page_type": "summary", "title": title, "api": resp.get("success")})

    # 实体页
    for ent in entities[: int(build_cfg.get("entity_count", 6))]:
        name = str(ent.get("name") or "").strip()
        definition = str(ent.get("definition") or "").strip()
        if not name:
            continue
        slug = f"entity-{kr.md5_hex(name, 8)}"
        content_md = f"# {name}\n\n{definition}"
        try:
            resp = kr.api_post(
                f"/api/v1/kbs/{kb_id}/wiki/pages",
                {"title": name, "content": content_md, "slug": slug, "page_type": "entity"},
            )
            created.append({"slug": slug, "page_type": "entity", "title": name, "api": resp.get("success")})
        except RuntimeError as e:
            created.append({"slug": slug, "page_type": "entity", "title": name, "error": str(e)[:120]})

    # 4) 重建链接（wiki 互链）
    try:
        kr.api_post(f"/api/v1/kbs/{kb_id}/wiki/rebuild-links", {})
    except RuntimeError as e:
        created.append({"warning": f"rebuild-links: {e}"})

    return {
        "success": True,
        "kb_id": kb_id,
        "document_id": document_id,
        "title": title,
        "pages": created,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="KB 文档编译进 wiki")
    parser.add_argument("--kb", help="kb_id（默认读 WEKNORA_KB_ID）")
    parser.add_argument("--doc", help="document_id（默认读 WEKNORA_DOC_NAME）")
    parser.add_argument("--dry-run", action="store_true", help="只生成不写入")
    args = parser.parse_args()

    kb_id = args.kb or kr.load_kb_id()
    document_id = args.doc or kr.load_doc_name()
    if not kb_id:
        print(json.dumps({"success": False, "error": "缺少 kb_id（WEKNORA_KB_ID 或 --kb）"}, ensure_ascii=False))
        return 2
    if not document_id:
        print(json.dumps({"success": False, "error": "缺少 document_id（WEKNORA_DOC_NAME 或 --doc）"}, ensure_ascii=False))
        return 2

    try:
        result = build_wiki(kb_id, document_id, dry_run=args.dry_run)
    except Exception as e:  # noqa: BLE001
        result = {"success": False, "error": str(e)[:300]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    sys.exit(main())