#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""kb_compilation API RPC helper — for the kb-wiki-builder skill.

统一从环境变量 + config.yaml 读取连接信息（与 WeKnora 技能 weknora_rpc.py 同款约定）：
  - API 入口:  env KB_API_BASE_URL > config.yaml kb.api_base_url
  - 服务账号:  env KB_API_USER/KB_API_PWD > config.yaml kb.api_user/api_pwd
  - 目标知识库: env WEKNORA_KB_ID（agent-gateway 任务注入）> config.yaml kb.kb_id
  - LLM:        env WEKNORA_LLM_* / LLM_* > config.yaml model: 段
"""
import json
import os
import sys
import time
import urllib.error
import urllib.request

# ---------------------------------------------------------------------------
# 配置读取（环境变量 > config.yaml）
# ---------------------------------------------------------------------------

CONFIG = {}


def _load_config():
    global CONFIG
    if CONFIG:
        return CONFIG
    cfg = {"kb": {}, "model": {}, "build": {}}
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (
        os.path.join(here, "..", "config.yaml"),
        os.path.join(here, "config.yaml"),
    ):
        if os.path.exists(cand):
            try:
                import yaml

                cfg.update(yaml.safe_load(open(cand, encoding="utf-8")) or {})
            except Exception:
                # yaml 不可用或损坏时用空配置兜底
                pass
            break
    CONFIG = cfg
    return cfg


def _env(name, fallback=""):
    v = os.environ.get(name, "")
    if v:
        return v
    # 回退 ~/.hermes/.env（网关侧常用）
    try:
        for line in open(os.path.expanduser("~/.hermes/.env"), encoding="utf-8"):
            line = line.strip()
            if line.startswith(name + "="):
                return line.split("=", 1)[1].strip()
    except Exception:
        pass
    return fallback


def api_base_url() -> str:
    cfg = _load_config()
    return _env("KB_API_BASE_URL", str(cfg.get("kb", {}).get("api_base_url", "http://10.1.215.50"))).rstrip("/")


def api_credentials() -> tuple[str, str]:
    cfg = _load_config()
    kb = cfg.get("kb", {})
    user = _env("KB_API_USER", str(kb.get("api_user", "admin")))
    pwd = _env("KB_API_PWD", str(kb.get("api_pwd", "sys")))
    return user, pwd


def load_kb_id() -> str:
    """目标知识库 id：任务注入环境变量优先，回退 config.yaml。"""
    cfg = _load_config()
    env_kb = _env("WEKNORA_KB_ID", "").strip()
    if env_kb:
        return env_kb
    return str(cfg.get("kb", {}).get("kb_id", "") or "").strip()


def load_doc_name() -> str:
    return _env("WEKNORA_DOC_NAME", "").strip()


def llm_config() -> tuple[str, str, str]:
    """(base_url, model, api_key)：任务级环境变量 > 容器 LLM_* > config.yaml。"""
    cfg = _load_config()
    m = cfg.get("model", {})
    base = _env("WEKNORA_LLM_BASE_URL", _env("LLM_BASE_URL", str(m.get("base_url", ""))))
    model = _env("WEKNORA_LLM_MODEL", _env("LLM_MODEL", str(m.get("default", ""))))
    key = _env("WEKNORA_LLM_API_KEY", _env("LLM_API_KEY", str(m.get("api_key", ""))))
    return base, model, key


# ---------------------------------------------------------------------------
# HTTP 客户端（带登录 cookie + 重试）
# ---------------------------------------------------------------------------

_COOKIE = ""
_LAST_401_TS = 0.0


def _login() -> str:
    """登录 kb 平台，返回 identity cookie。"""
    user, pwd = api_credentials()
    url = f"{api_base_url()}/api/v1/auth/login"
    body = json.dumps({"userId": user, "pwd": pwd}).encode()
    req = urllib.request.Request(
        url, data=body, method="POST",
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    ck = (data.get("identity_cookie") or "").strip()
    if not ck:
        raise RuntimeError(f"kb login failed: {data.get('message') or 'no cookie'}")
    return ck


def api_get(path: str, retries: int = 3) -> dict:
    global _COOKIE, _LAST_401_TS
    base = api_base_url()
    for attempt in range(retries):
        if not _COOKIE:
            _COOKIE = _login()
        req = urllib.request.Request(
            f"{base}{path}",
            headers={"Cookie": f"x-next-identity={_COOKIE}", "Accept": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 401:
                _COOKIE = ""  # 强制重登
                if attempt == retries - 1:
                    raise RuntimeError(f"kb API 401 after retries: {path}") from e
                time.sleep(1)
                continue
            raise RuntimeError(f"kb API GET {path} failed: HTTP {e.code} {e.read()[:200]!r}") from e


def api_post(path: str, payload: dict, retries: int = 3) -> dict:
    global _COOKIE
    base = api_base_url()
    for attempt in range(retries):
        if not _COOKIE:
            _COOKIE = _login()
        body = json.dumps(payload, ensure_ascii=False).encode()
        req = urllib.request.Request(
            f"{base}{path}", data=body, method="POST",
            headers={
                "Content-Type": "application/json",
                "Cookie": f"x-next-identity={_COOKIE}",
                "Accept": "application/json",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 401:
                _COOKIE = ""
                if attempt == retries - 1:
                    raise RuntimeError(f"kb API POST {path} failed: HTTP 401") from e
                time.sleep(1)
                continue
            # 409/400 返回 JSON 错误信息，读取后抛出
            try:
                err = json.loads(e.read().decode("utf-8"))
            except Exception:
                err = {"detail": str(e)}
            raise RuntimeError(f"kb API POST {path} failed: HTTP {e.code} {json.dumps(err, ensure_ascii=False)[:200]}") from e


def fetch_document_chunks(kb_id: str, document_id: str) -> list[dict]:
    """拉取文档 chunks（content 全文，供 LLM 编译 wiki）。"""
    path = f"/api/v1/kbs/{kb_id}/documents/{document_id}/chunks"
    resp = api_get(path)
    data = resp.get("data") or {}
    return data.get("items") or []


def create_wiki_page(kb_id: str, title: str, content: str, slug: str, page_type: str) -> dict:
    """写入 wiki 页面（幂等：同 slug 已存在则 PUT 更新）。"""
    payload = {
        "title": title,
        "content": content,
        "slug": slug,
        "page_type": page_type,
        "summary": content[:200] if page_type != "summary" else None,
    }
    # 先查 slug 是否已存在（GET wiki index 太大，直接尝试 POST；409 再 PUT）
    try:
        return api_post(f"/api/v1/kbs/{kb_id}/wiki/pages", payload)
    except RuntimeError as e:
        if "409" in str(e) or "已存在" in str(e) or "exists" in str(e).lower():
            up = api_post(f"/api/v1/kbs/{kb_id}/wiki/pages/update", {})  # placeholder
            return up
        raise


def llm_chat(messages: list[dict]) -> str:
    """OpenAI 兼容 LLM 调用（自动 403/429 退避）。"""
    base, model, key = llm_config()
    if not base or not model:
        raise RuntimeError(f"LLM 配置缺失: base={base!r} model={model!r}")
    url = f"{base.rstrip('/')}/chat/completions"
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    body = json.dumps({"model": model, "messages": messages, "temperature": 0.2}).encode()
    req = urllib.request.Request(url, data=body, headers=headers)
    with urllib.request.urlopen(req, timeout=180) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    try:
        return str(data["choices"][0]["message"]["content"] or "")
    except (KeyError, IndexError, TypeError):
        raise RuntimeError(f"LLM 响应异常: {json.dumps(data)[:300]}")


def md5_hex(text: str, n: int) -> str:
    import hashlib

    return hashlib.md5(text.encode("utf-8")).hexdigest()[:n]
